import java.io.*;
import java.lang.reflect.Array;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.naming.InitialContext;



public class DBApp implements Serializable {
	
	static String STATIC_DIR = "tables/";
	private ArrayList<String> tablesName = new ArrayList<String>(); ;

	public DBApp() {
		
	}
	
	
	
	public void init( ) {
		File file = new File("resources/metadata.csv");
        try {
            boolean created = file.createNewFile();
            if (created) {
                System.out.println("File created successfully");
            } else {
                System.out.println("File already exists");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
	}
	
	public void createTable(String strTableName,
							String strClusteringKeyColumn,
							Hashtable<String,String> htblColNameType,
							Hashtable<String,String> htblColNameMin,
							Hashtable<String,String> htblColNameMax )
							throws DBAppException {
		

		Table t = new Table(strTableName,
							strClusteringKeyColumn,
							htblColNameType,
							htblColNameMin,
							htblColNameMax);
		
		tablesName.add(strTableName);
		writeTable(t);
		t=null;	
		
	}
	
	public static boolean checkDuplicatePK(Table t, Hashtable<String,Object> htblColNameValue) {
		for(int i=0;i<t.getPagesPath().size();i++) {
			Page p = readPage(t.getPagesPath().get(i+1));
			String pk = getClusteringKey(t.getStrTableName());
			boolean isFound = binarySearch(p.getRows(), pk, htblColNameValue)== -1? false : true;
			t.writePage(p, t.getPagesPath().get(i+1));
			p=null;
			if(isFound) return isFound;
		}
		return false;
	}
	
	public static ArrayList<String> getIndexNames(String tableName){
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv"); 
		ArrayList<String> indexNames = new ArrayList<>();
		
		
		for(String[] row : fromCsv) {
			if(row[0].equalsIgnoreCase(tableName) && !row[4].equalsIgnoreCase("null") && !indexNames.contains(row[4])) {
				indexNames.add(row[4]);
			}
		}
		return indexNames;
		
	}
	
	public static ArrayList<String> getIndexedColumns(String tableName, String indexName) {
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv"); 
		ArrayList<String> indexedColumns = new ArrayList<String>();
		
		for(String[] row : fromCsv) {
			if(row[0].equals(tableName) && row[4].equalsIgnoreCase(indexName)) {
				indexedColumns.add(row[1]);
			}
		}
		
		return indexedColumns;
	}
	
	public static boolean isColumnIndexed(String tableName, String colName) {
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv"); 
		for(String[] row : fromCsv) {
			if(row[0].equals(tableName) && row[1].equals(colName) && !row[4].equalsIgnoreCase("null")) {
				return true;
			}
		}
		return false;
	}
	
	
	
	public static void updateObjectIndex(String tableName, Hashtable<String,Object> row,String path) {
		ArrayList<String> indexNames = getIndexNames(tableName);
		ObjectIndex res =null;
		for(String indexName : indexNames) {
			ArrayList<String> indexedCols = getIndexedColumns(tableName, indexName);
			Collections.sort(indexedCols);
			Comparable x = (Comparable) row.get(indexedCols.get(0));
			Comparable y = (Comparable) row.get(indexedCols.get(1));
			Comparable z = (Comparable) row.get(indexedCols.get(2));
			
			Octree oct = readIndex(indexName);
			res = oct.search(x, y, z);
			if(res!=null)
				res.setPagePath(path);
			writeIndex(oct);

		}
		
	}
	
	public void insertIntoTable(String strTableName,
			 					Hashtable<String,Object> htblColNameValue)
			 					throws DBAppException {
		
		
		Table t = readTable(strTableName);
		boolean dublicatePK = checkDuplicatePK(t, htblColNameValue);
		if(dublicatePK) {
			throw new DBAppException("Duplicate primary key");
		}
		//Check for types , min and max from meta data 
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv"); 
		checkValid(fromCsv,htblColNameValue, true);
		
		String clustringKey = getClusteringKey(t.getStrTableName());
		Object clustringKeyValue = htblColNameValue.get(clustringKey);
		
		if(t.getPageID()==0) { //No Pages 
			
			t.addPage();
			String path = t.getPagesPath().get(t.getPageID());
			Page p = readPage(path);
			p.getRows().add(htblColNameValue);  //inserting 
			t.writePage(p, path);
			p = null;
						
			
		} else {  	
			
			String pagePathToInsert = getPagePathToInsert(t.getPagesPath(), clustringKeyValue);
			Page pageToInsert = readPage(pagePathToInsert);
			
			
			int indexToInsert = binarySearchInsertionIndex(pageToInsert.getRows(), clustringKey, htblColNameValue);
			
			if(!pageToInsert.isFull()) { //page is not full insert directly
				
				pageToInsert.getRows().insertElementAt(htblColNameValue , indexToInsert);
				t.writePage(pageToInsert, pagePathToInsert);
				pageToInsert= null;
				
			} else {  //page full 
				 
				
				 
				if(pageToInsert.getPageNo() != t.getPagesPath().size()) { //full but not last
					 
					String nextPagePath = t.getPagesPath().get(pageToInsert.getPageNo()+1); 
					Page nextPage = readPage(nextPagePath);
					 
					Hashtable <String, Object> tmpIn = htblColNameValue;
					int size = pageToInsert.getRows().size();
					Hashtable <String, Object> tmpOut = pageToInsert.getRows().remove(size-1);
					
					pageToInsert.getRows().insertElementAt(tmpIn, indexToInsert);
					 
					t.writePage(pageToInsert, pagePathToInsert);
					pageToInsert=null;
					  
					while(nextPage.isFull() && nextPage.getPageNo() != t.getPagesPath().size() ) {
						tmpIn = tmpOut;
						tmpOut = nextPage.getRows().remove(size-1);
					
						nextPage.getRows().insertElementAt(tmpIn, 0);
						updateObjectIndex(strTableName, tmpIn,nextPagePath);
						
						t.writePage(nextPage, nextPagePath);
					 
						nextPagePath = t.getPagesPath().get(nextPage.getPageNo()+1); //mafesh page
						nextPage = readPage(nextPagePath);
					}
					int indexToInsertInNextPage = binarySearchInsertionIndex(nextPage.getRows(), clustringKey, tmpOut);

					if(!nextPage.isFull()) {
						nextPage.getRows().insertElementAt(tmpOut, indexToInsertInNextPage);
						updateObjectIndex(strTableName, tmpOut,nextPagePath);
						
					} else if(nextPage.getPageNo() == t.getPagesPath().size()) { //last and full 
						
						Hashtable <String, Object> lastRow = nextPage.getRows().remove(size-1);
						nextPage.getRows().insertElementAt(tmpOut, indexToInsertInNextPage);
						t.writePage(pageToInsert, pagePathToInsert);
						pageToInsert = null;
						t.addPage();
						String newPagePath = t.getPagesPath().get(t.getPageID());
						Page newPage = readPage(newPagePath);
						newPage.getRows().insertElementAt(lastRow, 0);
						updateObjectIndex(strTableName, lastRow,newPagePath);
						t.writePage(newPage, newPagePath);
						newPage=null;
					}
					t.writePage(nextPage, nextPagePath);
					nextPage=null;
					 
					 
				} else { //if page is full and the last
					Hashtable <String, Object> lastRow;
					
					if(indexToInsert == pageToInsert.getRows().size()) {
						lastRow = htblColNameValue;
					}
					else {
						int size = pageToInsert.getRows().size();
						lastRow = pageToInsert.getRows().remove(size-1);
						pageToInsert.getRows().insertElementAt(htblColNameValue, indexToInsert);
						t.writePage(pageToInsert, pagePathToInsert);
						pageToInsert=null;
					}
					t.addPage();
					String newPagePath = t.getPagesPath().get(t.getPageID());
					Page newPage = readPage(newPagePath);
					newPage.getRows().insertElementAt(lastRow, 0);
					updateObjectIndex(strTableName, lastRow,newPagePath);
					t.writePage(newPage, newPagePath);
					newPage = null;
					
		 
				}	  		 
			}	 	 
		}
		
				
		//serialize the table
		writeTable(t);
		updateMinMax(strTableName);
		t=null;	
		insertIntoIndex(strTableName, htblColNameValue);
		
	}
	
	public static void insertIntoIndex(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {
		ArrayList<String> indexNames = getIndexNames(strTableName);
		Table t = readTable(strTableName);
		String clusteringKey = getClusteringKey(strTableName);
		Object clustringKeyValue = htblColNameValue.get(clusteringKey);
		
		String pagePathToInsert = getPagePathToInsert(t.getPagesPath(), clustringKeyValue);
		writeTable(t);
		t=null;
		for(String name : indexNames) {
			ArrayList<String> indexedcolumns = getIndexedColumns(strTableName, name);
			Collections.sort(indexedcolumns);
			Comparable x =  (Comparable) htblColNameValue.get(indexedcolumns.get(0));
			Comparable y =  (Comparable) htblColNameValue.get(indexedcolumns.get(1));
			Comparable z =  (Comparable) htblColNameValue.get(indexedcolumns.get(2));
						
			ObjectIndex obj = new ObjectIndex(x, y, z, pagePathToInsert, (Comparable)clustringKeyValue);
			Octree oct = readIndex(name);
			oct.insert(obj);
			writeIndex(oct);
			oct=null;
	
		}
		
	}
	
	public static String getPagePathToInsert(Hashtable<Integer, String> pagesPath, Object value) {
		for(int i=0 ; i<pagesPath.size(); i++) {
			String path = pagesPath.get(i+1);
			Page p = readPage(path);
			if(p.getPageNo() == pagesPath.size()) {
				return path;
			}
			if (((Comparable) value).compareTo((Comparable) p.getMaxPK()) <= 0) {

				return path;
			}
			Table t = p.getParentTable();
			t.writePage(p, path);
			p=null;
		}
		return null;
	}
	
	
	
	public static void printTable(Table t) {
		for(int i=0; i<t.getPagesPath().size(); i++ ) {
			Page p = readPage(t.getPagesPath().get(i+1));
			System.out.println(t.getPagesPath().get(i+1));
			System.out.println(p.getRows());
			t.writePage(p, t.getPagesPath().get(i+1));
			p = null;
		}
		writeTable(t);
		t=null;
	}
	
	
	public static void updateMinMax(String name) {
		Table t = readTable(name);
	    String pk = getClusteringKey(t.getStrTableName());


	    for (int i=0;i<t.getPagesPath().size() ;i++) {
	    	String currPagePath = t.getPagesPath().get(i+1);
	        Page currPage = readPage(currPagePath);
	        Vector<Hashtable<String, Object>> rows = currPage.getRows();
	        
	        Object min = null;
	    	Object max = null;
	    	for(int j=0 ;j<rows.size() ;j++) {
	    	   
	    		Object pkValue = rows.get(j).get(pk);
	            
	            if (min == null || ((Comparable) pkValue).compareTo(min) < 0) {
	            	
	            	min =pkValue;
	           	
	            }
	            if (max == null || ((Comparable) pkValue).compareTo(max) > 0) {
	            	
	                max = pkValue;
	                
	            }
	       }
	       currPage.setMinPK(min);
	       currPage.setMaxPK(max);
	       t.writePage(currPage, currPagePath);
	       currPage=null;
	    }
	   writeTable(t);
	   t=null;
	}
	
	public static String getClusteringKey(String tableName) {
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv");
		String clusteringKey=null;
		for (String[] colMetadata : fromCsv) {
            if(colMetadata[3].equalsIgnoreCase("true") && tableName.equals(colMetadata[0])) {
            	clusteringKey = colMetadata[1];
            }
		}		
		return clusteringKey;
	}	
	
	public static int binarySearchInsertionIndex(Vector<Hashtable<String, Object>> rows, String clusteringKey, Hashtable<String, Object> newRow) {
	    int low = 0;
	    int high = rows.size() - 1;
	    int mid;

	    while (low <= high) {
	        mid = (low + high) / 2;
	        Comparable<Object> clusteringKeyValue = (Comparable<Object>) rows.get(mid).get(clusteringKey);
	        int comparisonResult = clusteringKeyValue.compareTo(newRow.get(clusteringKey));
	        if (comparisonResult == 0) {  
	            return mid;
	        } else if (comparisonResult < 0) { 
	            low = mid + 1;
	        } else {     
	            high = mid - 1;
	        }
	    }
	    return low;
	}
	
	public static int binarySearch(Vector<Hashtable<String, Object>> rows, String clusteringKey, Hashtable<String, Object> newRow) {
	    int low = 0;
	    int high = rows.size() - 1;
	    int mid;
	    int index = -1;

	    while (low <= high) {
	        mid = (low + high) / 2;
	        Comparable<Object> clusteringKeyValue = (Comparable<Object>) rows.get(mid).get(clusteringKey);
	        int comparisonResult = clusteringKeyValue.compareTo(newRow.get(clusteringKey));
	        if (comparisonResult == 0) {  
	            index = mid;
	            break;
	        } else if (comparisonResult < 0) { 
	            low = mid + 1;
	        } else {     
	            high = mid - 1;
	        }
	    }
	    return index;
	}
	

	
	public static int binarySearchWithPk(Vector<Hashtable<String, Object>> rows, String clusteringKey, Object clusteringKeyValue) throws DBAppException {
	    int low = 0;
	    int high = rows.size() - 1;
	    int mid;
	    int index = -1;
	    
	    while (low <= high) {
	        mid = (low + high) / 2;
	        Object keyValue = (Object) rows.get(mid).get(clusteringKey);
	        Object parsed = null;
		    if(keyValue instanceof java.lang.Integer) {
		    	try {
		    		parsed = Integer.parseInt(clusteringKeyValue.toString());
		    	} catch(NumberFormatException e){
		    		throw new DBAppException("invalid clustering key type");
		    	}
		    }
		    else if(keyValue instanceof java.lang.Double) {
		    	try {
		    		parsed = Double.parseDouble(clusteringKeyValue.toString());
		    	} catch(NumberFormatException e){
		    		throw new DBAppException("invalid clustering key type");
		    	}
		    }
		    else if(clusteringKeyValue instanceof java.util.Date) {
		        //parse to date
		    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				try {
					parsed = formatter.parse( (String) clusteringKeyValue );
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					throw new DBAppException("invalid clustering key type");
				}
		    }
		    else if(clusteringKeyValue instanceof java.lang.String) {
		        //parse to string
		    	parsed = clusteringKeyValue.toString();
		    }
		    else {
		        //handle other types throw an exception
		        throw new DBAppException("Unsupported data type: " + clusteringKeyValue.getClass().getName());
		    }
		    Comparable<Object> ComparableKeyValue = (Comparable<Object>) keyValue;
	        int comparisonResult = ComparableKeyValue.compareTo(parsed);
	        
	        if (comparisonResult == 0) {  
	            index = mid;
	            break;
	        } else if (comparisonResult < 0) { 
	            low = mid + 1;
	        } else {     
	            high = mid - 1;
	        }
	    }
	    return index;
	}


	
	public static void checkValid( List<String[]> fromCsv ,  Hashtable<String,Object> htblColNameValue, boolean fromInsert) throws DBAppException {
		for(String col : htblColNameValue.keySet()) {
		    boolean found = false;
		    for(String[] colMetadata : fromCsv) {
		        if(col.equals(colMetadata[1])) {
		            found = true;
		            break;
		        }
		    }
		    if(!found) {
		        throw new DBAppException("invalid column name");
		    }
		}
		
		for (String[] colMetadata : fromCsv) {
			String colName = colMetadata[1];
			String colType = colMetadata[2];
            String isClusteringKey = colMetadata[3];
            Object value = htblColNameValue.get(colName);
	            
	            
     		if(value == null) {
        	   if(isClusteringKey.equalsIgnoreCase("true") && fromInsert) {
        		   throw new DBAppException("Primary key cannot be NULL");
        	   }
        	   else {
        		   //the user didn't enter a value for this column
	        	   continue;
        	   }
     		}
            switch (colType) {
                case "java.lang.Integer":
                    if (!(value instanceof Integer)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }
                    Integer intValue = (Integer) value;
                    String minStr = colMetadata[6];
                    String maxStr = colMetadata[7];
                    int min = Integer.parseInt(minStr);
                    int max = Integer.parseInt(maxStr);
                    if (intValue < min || intValue > max) {
                        throw new DBAppException("Value out of range for column " + colName);
                    }
                    break;
                case "java.lang.String":
                    if (!(value instanceof String)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }
                    String strValue = (String) value;
                    int strMin = (int) colMetadata[6].charAt(0);
                    int strMax = (int) colMetadata[7].charAt(colMetadata[7].length() - 1);
                    int valueMin = (int) strValue.charAt(0);
                    int valueMax = (int) strValue.charAt(strValue.length() - 1);
                    if (valueMin < strMin || valueMax > strMax) {
                        throw new DBAppException("Value out of range for column " + colName);
                    }
                    break;
                case "java.lang.Double":
                    if (!(value instanceof Double)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }
                    Double doubleValue = (Double) value;
                    Double doubleMin = Double.parseDouble(colMetadata[6]);
                    Double doubleMax = Double.parseDouble(colMetadata[7]);
                    if (doubleValue < doubleMin || doubleValue > doubleMax) {
                        throw new DBAppException("Value out of range for column " + colName);
                    }
                    break;
                case "java.util.Date":
                	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                	Date dateValue = null;
					try {
						dateValue = formatter.parse((String) value);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						throw new DBAppException("Type mismatch for column " + colName);
					}
					Date dateMin = null;
					try {
						dateMin = (Date) new SimpleDateFormat("yyyy-MM-dd").parse(colMetadata[6]);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Date dateMax = null;
					try {
						dateMax = (Date) new SimpleDateFormat("yyyy-MM-dd").parse(colMetadata[7]);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    if (dateValue.before(dateMin) || dateValue.after(dateMax)) {
                        throw new DBAppException("Value out of range for column " + colName);
                    }
                    break;
                default:
                    throw new DBAppException("Unsupported data type for column " + colName);
            }  
		}
	}

	
	public void updateTable(String strTableName,
			String strClusteringKeyValue,
			Hashtable<String,Object> htblColNameValue )
			throws DBAppException {

		Table t = readTable(strTableName);
		
		List<String[]> fromCsv = readFromCsv("resources/metadata.csv");
		checkValid(fromCsv, htblColNameValue, false);
		
		boolean updated = false;
		String pk = getClusteringKey(strTableName);
		if(!isColumnIndexed(strTableName, pk)) {
			for(int i=0; i<t.getPagesPath().size();i++) {
			Page p = readPage(t.getPagesPath().get(i+1));
				int index = binarySearchWithPk(p.getRows(), pk, strClusteringKeyValue);
				
				if(index != -1) {
					Hashtable <String, Object> rowToUpdate = p.getRows().get(index);
					for(String col : htblColNameValue.keySet()) {
						if(col.equals(pk)) {
							throw new DBAppException("Cannot update primary key");
						}
						rowToUpdate.put(col, htblColNameValue.get(col));
					}
					updated = true;
				}
				t.writePage(p, t.getPagesPath().get(i+1));
				p=null;
			
			}
		}
		else {
			ArrayList<String> indexNames = getIndexNames(strTableName);
			for(String indexName : indexNames) {
				ArrayList<String> indexedCols = getIndexedColumns(strTableName, indexName);
				Collections.sort(indexedCols);
				int dimentionToSearch = indexedCols.indexOf(pk);
				if(dimentionToSearch == -1) {
					continue;
				}
				else {
					Octree oct = readIndex(indexName);
					ObjectIndex res = oct.searchWithValue(parsePK(strClusteringKeyValue), dimentionToSearch, "=").get(0);
	
					Page p = readPage(res.getPagePath());
					int indexToUpdate = binarySearchWithPk(p.getRows(), pk, strClusteringKeyValue);
					if(indexToUpdate != -1) {
						Hashtable <String, Object> rowToUpdate = p.getRows().get(indexToUpdate);
						for(String col : htblColNameValue.keySet()) {
							if(col.equals(pk)) {
								throw new DBAppException("Cannot update primary key");
							}
							int xOryOrz = indexedCols.indexOf(col);
							if(xOryOrz == 0) {
								res.setX((Comparable) htblColNameValue.get(col));
							} else if (xOryOrz == 1) {
								res.setY((Comparable) htblColNameValue.get(col));
							} else if (xOryOrz == 2) {
								res.setZ((Comparable) htblColNameValue.get(col));
							}
							rowToUpdate.put(col, htblColNameValue.get(col));
						}
						updated = true;
					}
					t.writePage(p, res.getPagePath());
					writeIndex(oct);
					p=null;
					oct=null;
					
				}
			}
		}
		writeTable(t);
		t=null;
		if(!updated) {
			throw new DBAppException("Record not found");
		}
	
	}
	
	public static Comparable parsePK(String value) {
        try {
            // Try parsing as Integer
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            try {
                // Try parsing as Double
                return Double.parseDouble(value);
            } catch (NumberFormatException ex) {
                try {
                    // Try parsing as Date
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = dateFormat.parse(value);
                    return date;
                } catch (ParseException exc) {
                    // Return as String if parsing fails for all types
                    return value;
                }
            }
        }
    }
	
	public static void checkValidDelete(List<String[]> fromCsv ,  Hashtable<String,Object> htblColNameValue) throws DBAppException {
		for(String col : htblColNameValue.keySet()) {
		    boolean found = false;
		    for(String[] colMetadata : fromCsv) {
		        if(col.equals(colMetadata[1])) {
		            found = true;
		            break;
		        }
		    }
		    if(!found) {
		        throw new DBAppException("invalid column name");
		    }
		}
		
		for (String[] colMetadata : fromCsv) {
			String colName = colMetadata[1];
			String colType = colMetadata[2];
            Object value = htblColNameValue.get(colName);
	            
	       if(value == null) {
	    	   continue;
	       }
            switch (colType) {
                case "java.lang.Integer":
                    if (!(value instanceof Integer)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }
                    break;
                case "java.lang.String":
                    if (!(value instanceof String)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }
                    break;
                case "java.lang.Double":
                    if (!(value instanceof Double)) {
                        throw new DBAppException("Type mismatch for column " + colName);
                    }  
                    break;
                case "java.util.Date":
                	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                	Date dateValue = null;
					try {
						dateValue = formatter.parse((String) value);
					}catch (ParseException e1) {
						throw new DBAppException("Type mismatch for column " + colName);
					}
                    break;
                default:
                    throw new DBAppException("Unsupported data type for column " + colName);
            }  
		}
	}
	
	
	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {
	    Table table = readTable(strTableName);
	    List<String[]> metadata = readFromCsv("resources/metadata.csv");
	    checkValidDelete(metadata, htblColNameValue);

	    String clusteringKey = getClusteringKey(table.getStrTableName());

	    if (htblColNameValue.containsKey(clusteringKey) && htblColNameValue.size() == 1) {
	    	System.out.println("clusterkey");
	        deleteRowsUsingClusteringKey(table, htblColNameValue, clusteringKey);
	    } else {
	        boolean useIndex = isAllIndexed(strTableName, htblColNameValue);

	        if (useIndex) {
	            for (String colName : htblColNameValue.keySet()) {
	                String indexName = getIndexNames(strTableName).get(0);
	                ArrayList<String> indexedColumns = getIndexedColumns(strTableName, indexName);
	                Collections.sort(indexedColumns);

	                int indexOfCol = indexedColumns.indexOf(colName);
	                Octree octree = readIndex(indexName);

	                deleteRowsUsingIndex(octree, htblColNameValue, indexOfCol, table ,indexedColumns);
	                writeIndex(octree);
	            }
	        } else {
	            deleteRowsWithoutIndex(table, htblColNameValue);
	        }
	    }

	    writeTable(table);
	    updateMinMax(strTableName);
	}

	private void deleteRowsUsingClusteringKey(Table table, Hashtable<String, Object> htblColNameValue, String clusteringKey) {
	    for (int i = 0; i < table.getPagesPath().size(); i++) {
	        String pagePath = table.getPagesPath().get(i + 1);
	        Page page = readPage(pagePath);

	        int indexToDelete = binarySearch(page.getRows(), clusteringKey, htblColNameValue);

	        if (indexToDelete != -1) {
	            page.getRows().remove(indexToDelete);

	            if (page.getRows().isEmpty()) {
	                table.getPagesPath().remove(i + 1);
	                table.setPageID(table.getPageID() - 1);
	                File pageFile = new File(pagePath);
	                boolean deleted = pageFile.delete();
	                if (deleted) {
	                    System.out.println("Page deleted successfully");
	                } else {
	                    System.out.println("Failed to delete page");
	                }
	            }
	            table.writePage(page, pagePath);
	            break;
	        }
	        table.writePage(page, pagePath);
	    }
	}

	private void deleteRowsUsingIndex(Octree octree, Hashtable<String, Object> htblColNameValue, int dimension, Table table , ArrayList<String> indexedColumns ) throws DBAppException {
	    ArrayList<ObjectIndex> rowsToRemove = new ArrayList<>();
	    Comparable valueToDelete = (Comparable) htblColNameValue.get(indexedColumns.get(dimension));
	    String operator = "=";

	    rowsToRemove.addAll(octree.searchWithValue(valueToDelete, dimension, operator));

	    for (ObjectIndex obj : rowsToRemove) {
	        Page indexedPage = readPage(obj.getPagePath());

	        ArrayList<Hashtable<String, Object>> rowsToDelete = new ArrayList<>();
	        for (Hashtable<String, Object> row : indexedPage.getRows()) {
	            boolean deleteRow = true;

	            for (String colName : htblColNameValue.keySet()) {
	                Object value = htblColNameValue.get(colName);
	                Object currValue = row.get(colName);

	                if (!currValue.equals(value)) {
	                    deleteRow = false;
	                    break;
	                }
	            }

	            if (deleteRow) {
	                rowsToDelete.add(row);
	                octree.delete(obj);
	            }
	        }

	        indexedPage.getRows().removeAll(rowsToDelete);
	        table.writePage(indexedPage, obj.getPagePath());
	    }
	}


	private void deleteRowsWithoutIndex(Table table, Hashtable<String, Object> htblColNameValue) {
		for (int i = 0; i < table.getPagesPath().size(); i++) {
			String pagePath = table.getPagesPath().get(i + 1);
			Page page = readPage(pagePath);
			ArrayList<Hashtable<String, Object>> rowsToRemove = new ArrayList<>();
		    for (Hashtable<String, Object> row : page.getRows()) {
		        boolean deleteRow = true;

		        for (String col : htblColNameValue.keySet()) {
		            Object valueToDelete = htblColNameValue.get(col);
		            Object currValue = row.get(col);

		            if (!currValue.equals(valueToDelete)) {
		                deleteRow = false;
		                break;
		            }
		        }

		        if (deleteRow) {
		            rowsToRemove.add(row);
		        }
		    }

		    if (!rowsToRemove.isEmpty()) {
		        page.getRows().removeAll(rowsToRemove);
		    }

		    if (page.getRows().isEmpty()) {
		        table.getPagesPath().remove(i + 1);
		        table.setPageID(table.getPageID() - 1);
		        File pageFile = new File(pagePath);
		        boolean deleted = pageFile.delete();
		        if (deleted) {
		            System.out.println("Page deleted successfully");
		        } else {
		            System.out.println("Failed to delete page");
		        }
		    }

		    table.writePage(page, pagePath);
		}
	}	


	
	public static Page readPage(String address) {
		Page page = null;
	    try {
	        FileInputStream fileIn = new FileInputStream(address);
	        ObjectInputStream in = new ObjectInputStream(fileIn);
	        page = (Page) in.readObject();
	        in.close();
	        fileIn.close();
	    } catch (IOException i) {
	    	i.printStackTrace();
	    } catch (ClassNotFoundException c) {
	        c.printStackTrace();
	    }
	    return page;  
	}
	
	public static List<String[]> readFromCsv(String filePath) {
	    List<String[]> dataList = new ArrayList<>();

	    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
	        String line;
	        while ((line = br.readLine()) != null) {
	            String[] data = line.split(",");
	            dataList.add(data);
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    
	    return dataList;
	}
	
	public static void writeIndex(Octree oct) {
		
		 try {
	         FileOutputStream fileOut = new FileOutputStream( "indices/" + oct.getName() + ".ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(oct);
	         out.close();
	         fileOut.close();
//	         System.out.println("Serialized data is saved in /indices.ser");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
		 System.gc();
		
	}
	
	public static Octree readIndex(String indexName) {
		Octree oct = null;
	    try {
	        FileInputStream fileIn = new FileInputStream("indices/" + indexName + ".ser");
	        ObjectInputStream in = new ObjectInputStream(fileIn);
	        oct = (Octree) in.readObject();
	        in.close();
	        fileIn.close();
	    } catch (IOException i) {
	        i.printStackTrace();
	    } catch (ClassNotFoundException c) {
	        c.printStackTrace();
	    }
	    return oct;
		
	}

	public static void writeTable(Table t) {
		
		 try {
	         FileOutputStream fileOut = new FileOutputStream( STATIC_DIR + t.getStrTableName() + ".ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(t);
	         out.close();
	         fileOut.close();
//	         System.out.println("Serialized data is saved in /table.ser");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
		 System.gc();
		
	}
		
	public static Table readTable(String tableName) {
		Table table = null;
	    try {
	        FileInputStream fileIn = new FileInputStream(STATIC_DIR +tableName+".ser");
	        ObjectInputStream in = new ObjectInputStream(fileIn);
	        table = (Table) in.readObject();
	        in.close();
	        fileIn.close();
	    } catch (IOException i) {
	        i.printStackTrace();
	    } catch (ClassNotFoundException c) {
	        c.printStackTrace();
	    }
	    return table;
		
	}
	
	
	public void createIndex(String strTableName,
			String[] strarrColName) throws DBAppException {
		
		if(strarrColName.length != 3) {
			throw new DBAppException("Cannot create an octree index with less or more than 3 columns ");
		}
		
		
		else {
			Comparable minX = null;
			Comparable maxX = null;
			Comparable minY = null;
			Comparable maxY = null;
			Comparable minZ = null;
			Comparable maxZ = null;
			boolean flagX = false;
			boolean flagY = false;
			boolean flagZ = false;
			String indexName = "";
			
			List<String[]> fromCsv = readFromCsv("resources/metadata.csv");
			Arrays.sort(strarrColName);
						
			for(int i=0 ; i<strarrColName.length ; i++) {
				for(String[] col : fromCsv) {
					if(col[1].equals(strarrColName[i]) && col[0].equals(strTableName)) {
						if(!flagX) {
							switch(col[2]) {
							case "java.lang.Integer":
								minX = Integer.parseInt(col[6]);
								maxX = Integer.parseInt(col[7]);
								break;
							case "java.lang.String":
								minX = col[6];
								maxX = col[7];
								break;
							case "java.lang.Double":
								minX = Double.parseDouble(col[6]);
								maxX = Double.parseDouble(col[7]);
								break;
							case "java.util.Date":
								DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			                    Date date = null;
								try {
									date = format.parse(col[6]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    minX = date;
			                    
			                    Date date2 = null;
								try {
									date2 = format.parse(col[7]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    minX = date2;
			                    break;
							}
						
							flagX = true;
							break;
						}
						if(!flagY) {
							switch(col[2]) {
							case "java.lang.Integer":
								minY = Integer.parseInt(col[6]);
								maxY = Integer.parseInt(col[7]);
								break;
							case "java.lang.String":
								minY = col[6];
								maxY = col[7];
								break;
							case "java.lang.Double":
								minY = Double.parseDouble(col[6]);
								maxY = Double.parseDouble(col[7]);
								break;
							case "java.util.Date":
								DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			                    Date date = null;
								try {
									date = format.parse(col[6]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    minY = date;
			                    
			                    Date date2 = null;
								try {
									date2 = format.parse(col[7]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    minY = date2;
			                    break;
							}
							flagY = true;
							break;
						}
						if(!flagZ) {
							switch(col[2]) {
							case "java.lang.Integer":
								minZ = Integer.parseInt(col[6]);
								maxZ = Integer.parseInt(col[7]);
								break;
							case "java.lang.String":
								minZ = col[6];
								maxZ = col[7];
								break;
							case "java.lang.Double":
								minZ = Double.parseDouble(col[6]);
								maxZ = Double.parseDouble(col[7]);
								break;
							case "java.util.Date":
								DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			                    Date date = null;
								try {
									date = format.parse(col[6]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    minZ = date;
			                    
			                    Date date2 = null;
								try {
									date2 = format.parse(col[7]);
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			                    maxZ = date2;
			                    break;
							}
							flagZ = true;
							break;
						}
					}
					
				}
			}
			
			
			for(int i=0 ; i<strarrColName.length;i++) {
				indexName += strarrColName[i];
			}
			
			for(String[] col : fromCsv) {
				for(int i=0 ; i<strarrColName.length ; i++) {
					if(col[1].equals(strarrColName[i]) && col[0].equals(strTableName)) {
						col[4] = indexName;
						col[5] = "Octree";
					}
				}
			}
			
			writeToCsv("resources/metadata.csv", fromCsv);

			
			Node root = new Node(minX, maxX, minY, maxY, minZ, maxZ);
			Octree oct = new Octree(root, indexName);
			
			writeIndex(oct);
			oct=null;
			
			Table t = readTable(strTableName);
			
			if(t.getPagesPath().size()!=0) {
				
				for(int i=0 ; i<t.getPagesPath().size(); i++) {
					Page p = readPage(t.getPagesPath().get(i+1));
					for(Hashtable<String, Object> row : p.getRows()) {
						insertIntoIndex(strTableName, row);
					}
					t.writePage(p, t.getPagesPath().get(i+1));
					p=null;
				}
				
			}
			
			writeTable(t);
			t=null;
			
		}
	}
	
	public static void writeToCsv(String filePath, List<String[]> dataList) {
	    try {
	        FileWriter writer = new FileWriter(filePath);
	        for (String[] data : dataList) {
	            for (int i = 0; i < data.length; i++) {
	                writer.append(data[i]);
	                if (i != data.length - 1) {
	                    writer.append(",");
	                }
	            }
	            writer.append("\n");
	        }
	        writer.flush();
	        writer.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public Iterator selectFromTable(SQLTerm[] arrSQLTerms,
			String[] strarrOperators) throws DBAppException{
		
			if(arrSQLTerms.length-1 != strarrOperators.length) {
				throw new DBAppException("Number of operators is incorrect");
			}
		    if(!isQueryIndexed(arrSQLTerms, strarrOperators)) {
		    	System.out.println("no index");
				Vector<Hashtable<String, Object>> resultRows = new Vector<>();
			    SQLTerm firstTerm = arrSQLTerms[0];
			    resultRows.addAll(getRows(firstTerm));
			    
			
				for(int i =0 ; i<strarrOperators.length; i++) {
					SQLTerm term =  arrSQLTerms[i+1];	
					
					Vector<Hashtable<String,Object>> term2Rows =getRows(term);
				    
					String operator = strarrOperators[i];
					performOperator(resultRows,term2Rows,operator);
					
					
				}
				return resultRows.iterator();
		    } else {
		    	if(arrSQLTerms.length == 3) {
		    		System.out.println("indexed not patrial");
		    		return preformIndexedSelection(getIndexedTerms(arrSQLTerms)).iterator();
		    	}
		    	else {
		    		System.out.println("partial");
					Vector<Hashtable<String, Object>> resultRows = new Vector<>();
					resultRows = preformIndexedSelection(getIndexedTerms(arrSQLTerms));
					
					for(int i =0 ; i<arrSQLTerms.length; i++) {
						SQLTerm term =  arrSQLTerms[i];	
						if(isColumnIndexed(term.strTableName, term.strColumnName)) {
							continue;
						}
						else {
							Vector<Hashtable<String,Object>> term2Rows =getRows(term);
						    
							String operator = i==0? strarrOperators[i] : strarrOperators[i-1];
							performOperator(resultRows,term2Rows,operator);
						}
						
					}
					return resultRows.iterator();
		    	}
		    }
		    
		    
					
	}
	
	public static Vector<Hashtable<String,Object>> preformIndexedSelection(ArrayList<SQLTerm> terms) throws DBAppException{
		Vector<Hashtable<String, Object>> resultRows = new Vector<>();
	    SQLTerm firstTerm = terms.get(0);
    	resultRows.addAll(getRowsWithIndex(firstTerm));

		for(int i =0; i<terms.size()-1 ; i++) {
			SQLTerm term =  terms.get(i+1);
			Vector<Hashtable<String,Object>> term2Rows = getRowsWithIndex(term);
			performOperator(resultRows,term2Rows,"AND");
		}
		
		return resultRows;
	}
	
	public static ArrayList<SQLTerm> getIndexedTerms(SQLTerm[] arrSQLTerms){
		ArrayList<SQLTerm> res = new ArrayList<>();
		for(int i=0; i<arrSQLTerms.length; i++) {
			if(isColumnIndexed(arrSQLTerms[i].getStrTableName(), arrSQLTerms[i].getStrColumnName())) {
				res.add(arrSQLTerms[i]);
			}
		}
		return res;
	}
	
	
	
	
	public static Vector<Hashtable<String,Object>> getRowsWithIndex(SQLTerm term) throws DBAppException{
		Vector<Hashtable<String,Object>> matchedRows = new Vector<Hashtable<String,Object>>();
		ArrayList<String> indexNames = getIndexNames(term.getStrTableName());
		Table t = readTable(term.getStrTableName());
		String pk = getClusteringKey(term.getStrTableName());
		
		for(String indexName : indexNames) {
			ArrayList<String> indexedCols = getIndexedColumns(term.getStrTableName(), indexName);
			Collections.sort(indexedCols);
			int index = indexedCols.indexOf(term.getStrColumnName());

			if(index!= -1) {
				Octree oct = readIndex(indexName);
				ArrayList<ObjectIndex> res = oct.searchWithValue((Comparable)term.getObjValue(), index, term.getStrOperator());
				for(ObjectIndex o : res) {
					Page p = readPage(o.getPagePath());
					int indexOfRow = binarySearchWithPk(p.getRows(), pk, o.getPrimaryKey());
					matchedRows.add(p.getRows().get(indexOfRow));
					t.writePage(p, o.getPagePath());
				}
			writeTable(t);
				
			}
			else {
				throw new DBAppException("not found");
			}
		}
		return matchedRows;
	}
	
	public static Vector<Hashtable<String,Object>> getRows(SQLTerm term){
		 
		Vector<Hashtable<String,Object>> matchedRows = new Vector<Hashtable<String,Object>>();
	 		
		Table t = readTable(term.getStrTableName());
		 
		for(int i =0; i<t.getPagesPath().size();i++) {
			Page p = readPage(t.getPagesPath().get(i+1));
			for(Hashtable<String,Object> row : p.getRows()) {
				for(String col : row.keySet()) {
					if(col.equals(term.getStrColumnName())) {
						switch (term.getStrOperator()) {
						case "=" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) ==0) 
								matchedRows.add(row);
							break;
						case "!=" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) !=0) 
								matchedRows.add(row);
							break;
						case "<=" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) <=0) 
								matchedRows.add(row);
							break;
						case "<" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) <0) 
								matchedRows.add(row);
							break;
						case ">=" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) >=0) 
								matchedRows.add(row);
							break;
						case ">" :
							if(((Comparable) row.get(col)).compareTo((Comparable)term.getObjValue()) >0) 
								matchedRows.add(row);
							break;
						
						 } 
					 }
				 }
			 }
			t.writePage(p,t.getPagesPath().get(i+1));
		 }
		 
		 writeTable(t);
		 
		 
		 
		return matchedRows;
		 
	 }
	
	public static boolean isQueryIndexed(SQLTerm[] arrSQLTerms,
			String[] strarrOperators) {
		boolean flag = false;
		if(arrSQLTerms.length<3 || strarrOperators.length<2) {
			return false;
		}
		for(int i=0; i<arrSQLTerms.length-2; i++) {
			if(isColumnIndexed(arrSQLTerms[i].getStrTableName(),arrSQLTerms[i].getStrColumnName()) 
					&& isColumnIndexed(arrSQLTerms[i+1].getStrTableName(),arrSQLTerms[i+1].getStrColumnName())
					&& isColumnIndexed(arrSQLTerms[i+2].getStrTableName(),arrSQLTerms[i+2].getStrColumnName())) {
				if(strarrOperators[i].equalsIgnoreCase("and") && strarrOperators[i+1].equalsIgnoreCase("and")){
					flag = true;
				}
			}
		}
		return flag;
		
		
	}
	
	public static boolean isAllIndexed(String tableName, Hashtable<String, Object> htblColNameValue) {
		for(String col : htblColNameValue.keySet()) {
			if(!isColumnIndexed(tableName, col)) {
				return false;
			}
		}
		return true;
	}
	
	public static Vector<Hashtable<String,Object>> performOperator(
				Vector<Hashtable<String,Object>> leftVector, 
				Vector<Hashtable<String,Object>> rightVector, 
				String op) throws DBAppException{
		
	    switch (op){
	        case "AND":
	            Vector<Hashtable<String,Object>> toBeRemoved = new Vector<Hashtable<String,Object>>();
	            for (Hashtable<String,Object> element : leftVector)
	                if (!rightVector.contains(element))
	                    toBeRemoved.add(element);

	            leftVector.removeAll(toBeRemoved);
	            return leftVector;


	        case "OR":
	            for (Hashtable<String,Object> row : rightVector)
	                if (!leftVector.contains(row))
	                    leftVector.add(row);
	            return leftVector;


	        case "XOR":
	            //Vector<Hashtable<String,Object>> result = new Vector<Hashtable<String,Object>>();
	            for (Hashtable<String,Object> intRangeValue : rightVector)
	                if (!leftVector.contains(intRangeValue))
	                	leftVector.add(intRangeValue);
	                else
	                    leftVector.remove(intRangeValue);
	            
	            return leftVector;
	            
	        default :
				throw new DBAppException("Unsupported Operator");    
	    }
	    
			
	}
	
	
	public static void main(String[] args) throws DBAppException {
		
	}
}
