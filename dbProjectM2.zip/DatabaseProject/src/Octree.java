import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.sql.Date;
import java.util.ArrayList;

public class Octree implements Serializable {
	private Node root;
	private String name;
	
	public Octree(Node root, String name) {
		this.root = root;
		this.name = name;
	}
	
	public void insert(ObjectIndex objectToInsert) throws DBAppException {
		
		if (objectToInsert.getX().compareTo(root.getMinX()) >= 0 
				&& objectToInsert.getX().compareTo(root.getMaxX()) < 0
				&& objectToInsert.getY().compareTo(root.getMinY()) >= 0
				&& objectToInsert.getY().compareTo(root.getMaxY()) < 0
				&& objectToInsert.getZ().compareTo(root.getMinZ()) >= 0
				&& objectToInsert.getZ().compareTo(root.getMaxZ()) < 0) {
			
			
			insertIntoNode(objectToInsert, root);
		}
		else {
			throw new DBAppException("cannot insert this index");
		}
	}
		
	public void insertIntoNode(ObjectIndex objectToInsert, Node node) throws DBAppException {
		
		if(node.isLeaf()) {
			
			for(ObjectIndex o : node.getNodeEntries()) { //check duplicates
				if(o.getX().compareTo(objectToInsert.getX()) == 0 
						&& o.getY().compareTo(objectToInsert.getY()) == 0 
						&& o.getZ().compareTo(objectToInsert.getZ()) == 0 ) {
					node.getDuplicates().add(objectToInsert);
					return;
				}
			}
			
			if(!node.isFull()) {
				node.getNodeEntries().add(objectToInsert);
			}
			else {
				splitNode(node);
				
				for(int i=0;i<node.getNodeEntries().size();i++) {
					
					ObjectIndex o = node.getNodeEntries().remove(i);
					for(int j=0; j<node.getDuplicates().size(); j++) {
						ObjectIndex dup = node.getDuplicates().remove(j);
						j--;
						insertIntoNode(dup,node);
					}
					
					i--;
					insertIntoNode(o,node);
					
				}
				insertIntoNode(objectToInsert,node);
			}
		}
		else {
			
			for(int i=0; i<node.getChildren().size();i++) {
				Node child = node.getChildren().get(i);
				if (objectToInsert.getX().compareTo(child.getMinX()) >= 0 
						&& objectToInsert.getX().compareTo(child.getMaxX()) < 0
						&& objectToInsert.getY().compareTo(child.getMinY()) >= 0
						&& objectToInsert.getY().compareTo(child.getMaxY()) < 0
						&& objectToInsert.getZ().compareTo(child.getMinZ()) >= 0
						&& objectToInsert.getZ().compareTo(child.getMaxZ()) < 0) {
					
					
					insertIntoNode(objectToInsert, child);
				}
			}
		}
			
	}
	
	public static void splitNode(Node node) throws DBAppException{
		
		Comparable midX = getMid(node.getMinX(),node.getMaxX());
		Comparable midY = getMid(node.getMinY(),node.getMaxY());
		Comparable midZ = getMid(node.getMinZ(),node.getMaxZ());
		
		Node one = new Node(node.getMinX(), midX, node.getMinY(), midY, node.getMinZ(), midZ );
		Node two = new Node(node.getMinX(), midX, node.getMinY(), midY,  midZ , node.getMaxZ() );
		Node three = new Node(node.getMinX(),midX, midY, node.getMaxY(), node.getMinZ(), midZ );
		Node four = new Node(node.getMinX() ,midX, midY, node.getMaxY(), midZ , node.getMaxZ() );
		Node five = new Node(midX, node.getMaxX(), node.getMinY(), midY, node.getMinZ(), midZ );
		Node six = new Node(midX, node.getMaxX(), node.getMinY(), midY, midZ , node.getMaxZ() );
		Node seven = new Node(midX, node.getMaxX(), midY, node.getMaxY(), node.getMinZ(), midZ );
		Node eight = new Node(midX, node.getMaxX(), midY, node.getMaxY(), midZ , node.getMaxZ() );
		
		node.getChildren().add(one);
		node.getChildren().add(two);
		node.getChildren().add(three);
		node.getChildren().add(four);
		node.getChildren().add(five);
		node.getChildren().add(six);
		node.getChildren().add(seven);
		node.getChildren().add(eight);
		
		
	}
	
	
	public static Comparable getMid(Comparable min, Comparable max) throws DBAppException {
	   
	    if (min instanceof Integer) {
	        int mid = ((Integer) min + (Integer) max) / 2;
	        return mid;
	    } else if (min instanceof String) {
	        String mid = min.toString() + max.toString();
	        int len = mid.length() / 2;
	        return mid.substring(len, len + 1);
	    } else if (min instanceof Double) {
	        double mid = ((Double) min + (Double) max) / 2;
	        return mid;
	    } else if (min instanceof Date) {
	        long mid = ((Date) min).getTime() + (((Date) max).getTime() - ((Date) min).getTime()) / 2;
	        return new Date(mid);
	    } else {
	        throw new DBAppException("Objects are not comparable");
	    }
	}
	
	public void delete(ObjectIndex obj) throws DBAppException {
	    deleteFromNode(obj, root);
	}

	public void deleteFromNode(ObjectIndex obj, Node node) throws DBAppException {
		
		//delete duplicates
	    if (node.isLeaf()) {

	        node.getNodeEntries().remove(obj);	    
	        
	    } else {
	        for (int i = 0; i < node.getChildren().size(); i++) {
	            Node child = node.getChildren().get(i);
	            if (obj.getX().compareTo(child.getMinX()) >= 0 
	                    && obj.getX().compareTo(child.getMaxX()) < 0
	                    && obj.getY().compareTo(child.getMinY()) >= 0
	                    && obj.getY().compareTo(child.getMaxY()) < 0
	                    && obj.getZ().compareTo(child.getMinZ()) >= 0
	                    && obj.getZ().compareTo(child.getMaxZ()) < 0) {
	                
	            	deleteFromNode(obj, child);	                   
	            	break;
	              
	            }
	        }
	    }
	}
	
	public ObjectIndex search(Comparable x, Comparable y, Comparable z) {
	    return searchNode(x, y, z, root);
	}

	private ObjectIndex searchNode(Comparable x, Comparable y, Comparable z, Node node) {
	    if (node.isLeaf()) {
	        for (ObjectIndex o : node.getNodeEntries()) {
	            if (o.getX().equals(x) && o.getY().equals(y) && o.getZ().equals(z)) {
	                return o;
	            }
	        }
	        return null;
	    } else {
	        for (Node child : node.getChildren()) {
	            if (x.compareTo(child.getMinX()) >= 0 
	                    && x.compareTo(child.getMaxX()) < 0
	                    && y.compareTo(child.getMinY()) >= 0
	                    && y.compareTo(child.getMaxY()) < 0
	                    && z.compareTo(child.getMinZ()) >= 0
	                    && z.compareTo(child.getMaxZ()) < 0) {
	                
	                ObjectIndex result = searchNode(x, y, z, child);
	                if (result != null) {
	                    return result;
	                }
	            }
	        }
	        return null;
	    }
	}
		
	
	public ArrayList<ObjectIndex> searchWithValue(Comparable value, int dimension, String operator) {
	    ArrayList<ObjectIndex> result = new ArrayList<>();
	    searchWithValueHelper(dimension, value, operator, root, result);
	    return result;
	}

	public void searchWithValueHelper(int dimension, Comparable value, String operator, Node node, ArrayList<ObjectIndex> result) {
	    if (node == null) {
	        return;
	    }

	    if (node.isLeaf()) {
	        for (ObjectIndex object : node.getNodeEntries()) {
	            Comparable<Object> keyValue = getKeyValue(object, dimension);
	            if (compareValues(keyValue, value, operator)) {
	                result.add(object);
	            }
	        }
	    } else {
	        for (Node child : node.getChildren()) {
	            if (checkRange(child, dimension, value, operator)) {
	                searchWithValueHelper(dimension, value, operator, child, result);
	            }
	        }
	    }
	}

	private Comparable<Object> getKeyValue(ObjectIndex object, int dimension) {
	    if (dimension == 0) {
	        return object.getX();
	    } else if (dimension == 1) {
	        return object.getY();
	    } else if (dimension == 2) {
	        return object.getZ();
	    }
	    return null;
	}

	private boolean checkRange(Node node, int dimension, Comparable value, String operator) {
	    Comparable<Object> minValue = getMinValue(node, dimension);
	    Comparable<Object> maxValue = getMaxValue(node, dimension);

	    if (operator.equals(">=")) {
	        return maxValue.compareTo(value) >= 0;
	    } else if (operator.equals(">")) {
	        return maxValue.compareTo(value) > 0;
	    } else if (operator.equals("<=")) {
	        return minValue.compareTo(value) <= 0;
	    } else if (operator.equals("<")) {
	        return minValue.compareTo(value) < 0;
	    } else if (operator.equals("=")) {
	        return minValue.compareTo(value) <= 0 && maxValue.compareTo(value) >= 0;
	    } else if (operator.equals("!=")) {
	        return minValue.compareTo(value) > 0 || maxValue.compareTo(value) < 0;
	    }

	    return false;
	}

	private boolean compareValues(Comparable<Object> keyValue, Comparable value, String operator) {
	    if (operator.equals(">=")) {
	        return keyValue.compareTo(value) >= 0;
	    } else if (operator.equals(">")) {
	        return keyValue.compareTo(value) > 0;
	    } else if (operator.equals("<=")) {
	        return keyValue.compareTo(value) <= 0;
	    } else if (operator.equals("<")) {
	        return keyValue.compareTo(value) < 0;
	    } else if (operator.equals("=")) {
	        return keyValue.compareTo(value) == 0;
	    } else if (operator.equals("!=")) {
	        return keyValue.compareTo(value) != 0;
	    }

	    return false;
	}

	private Comparable<Object> getMinValue(Node node, int dimension) {
	    if (dimension == 0) {
	        return node.getMinX();
	    } else if (dimension == 1) {
	        return node.getMinY();
	    } else if (dimension == 2) {
	        return node.getMinZ();
	    }
	    return null;
	}

	private Comparable<Object> getMaxValue(Node node, int dimension) {
	    if (dimension == 0) {
	        return node.getMaxX();
	    } else if (dimension == 1) {
	        return node.getMaxY();
	    } else if (dimension == 2) {
	        return node.getMaxZ();
	    }
	   
	    return null;
	}

	
	public void update(ObjectIndex obj) throws DBAppException {
	    delete(obj);
	    insert(obj);
	}
		

	public Node getRoot() {
		return root;
	}

	public void setRoot(Node root) {
		this.root = root;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static void main(String[] args) throws DBAppException {
		
	}
	
	
}


