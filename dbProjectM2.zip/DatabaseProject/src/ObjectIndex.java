import java.io.Serializable;
import java.util.ArrayList;

public class ObjectIndex implements Serializable {
	private Comparable x;
	private Comparable y;
	private Comparable z;
	private String pagePath;
	private Comparable primaryKey;
	
	public ObjectIndex(Comparable x, Comparable y, Comparable z, String pagePath, Comparable primaryKey ) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.pagePath = pagePath;
		this.primaryKey = primaryKey;
	}

	public Comparable getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(Comparable primaryKey) {
		this.primaryKey = primaryKey;
	}

	public Comparable getX() {
		return x;
	}

	public void setX(Comparable x) {
		this.x = x;
	}

	public Comparable getY() {
		return y;
	}

	public void setY(Comparable y) {
		this.y = y;
	}

	public Comparable getZ() {
		return z;
	}

	public void setZ(Comparable z) {
		this.z = z;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}
	
	public String toString() {
		return "x = " + x + "\n" + "y = " + y + "\n" + "z = " + z + "\n" + "pagePath = " + pagePath; 
	}
	
	
}
