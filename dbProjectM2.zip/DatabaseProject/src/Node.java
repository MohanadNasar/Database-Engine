import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

public class Node implements Serializable{
	
	private Comparable minX;
	private Comparable maxX;
	private Comparable minY;
	private Comparable maxY;
	private Comparable minZ;
	private Comparable maxZ;
	private ArrayList<Node> children;
	private ArrayList<ObjectIndex> nodeEntries;
	private ArrayList<ObjectIndex> duplicates;
	private int NodeID;

	
	
	public Node(Comparable minX ,Comparable maxX, Comparable minY,
			Comparable maxY, Comparable minZ, Comparable maxZ) {
		
		this.minX = minX;
		this.maxX = maxX;
		this.minY = minY;
		this.maxY = maxY;
		this.minZ = minZ;
		this.maxZ = maxZ;
		this.children = new ArrayList<>();
		this.nodeEntries = new ArrayList<>(readFromConfig());
		this.duplicates = new ArrayList<>();
		this.setNodeID(this.getNodeID() + 1);
	}
	
	public ArrayList<ObjectIndex> getDuplicates() {
		return duplicates;
	}

	public void setDuplicates(ArrayList<ObjectIndex> duplicates) {
		this.duplicates = duplicates;
	}

	public static int readFromConfig() {
		Properties prop = new Properties();
		try (FileInputStream fis = new FileInputStream("resources/DBApp.config")) { //what file name to write here
		    prop.load(fis);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		int N= Integer.parseInt(prop.getProperty("MaximumEntriesinOctreeNode"));
		return N;
	}

	public boolean isFull() {
		return nodeEntries.size() == readFromConfig();
	}
	
	public boolean isLeaf() {
		return this.getChildren().size() == 0;
	}
	
	
	
	public Comparable getMinX() {
		return minX;
	}


	public void setMinX(Comparable minX) {
		this.minX = minX;
	}


	public Comparable getMaxX() {
		return maxX;
	}


	public void setMaxX(Comparable maxX) {
		this.maxX = maxX;
	}


	public Comparable getMinY() {
		return minY;
	}


	public void setMinY(Comparable minY) {
		this.minY = minY;
	}


	public Comparable getMaxY() {
		return maxY;
	}


	public void setMaxY(Comparable maxY) {
		this.maxY = maxY;
	}


	public Comparable getMinZ() {
		return minZ;
	}


	public void setMinZ(Comparable minZ) {
		this.minZ = minZ;
	}


	public Comparable getMaxZ() {
		return maxZ;
	}


	public void setMaxZ(Comparable maxZ) {
		this.maxZ = maxZ;
	}


	public ArrayList<Node> getChildren() {
		return children;
	}


	public void setChildren(ArrayList<Node> children) {
		this.children = children;
	}


	public ArrayList<ObjectIndex> getNodeEntries() {
		return nodeEntries;
	}


	public void setNodeEntries(ArrayList<ObjectIndex> nodeEntries) {
		this.nodeEntries = nodeEntries;
	}

	public int getNodeID() {
		return NodeID;
	}

	public void setNodeID(int nodeID) {
		NodeID = nodeID;
	}
	
	
	
	
}
