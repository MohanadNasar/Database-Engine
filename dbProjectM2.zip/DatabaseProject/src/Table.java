import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Collections;
import java.util.HashMap;



public class Table implements Serializable {
	
	//private ArrayList<String> strarrPagesAddresses;
	private String strTableName;
	private String strClusteringKeyColumn;
	private Hashtable<String,String> htblColNameType;
	private Hashtable<String,String> htblColNameMin;
	private Hashtable<String,String> htblColNameMax;
	private int pageID;
	
	private static String STATIC_DIR = "pages/";
	
	private Hashtable <Integer,String> pagesPath ; 


	public Table(String strTableName,
				 String strClusteringKeyColumn,
				 Hashtable<String,String> htblColNameType,
				 Hashtable<String,String> htblColNameMin,
				 Hashtable<String,String> htblColNameMax ) throws DBAppException {
		
					this.strTableName=strTableName;
					this.strClusteringKeyColumn=strClusteringKeyColumn;
					this.htblColNameType=htblColNameType;
					this.htblColNameMin=htblColNameMin;
					this.htblColNameMax=htblColNameMax;
					this.pagesPath = new Hashtable<Integer, String>();
					this.pageID=0;
					
					
					
					List<String[]> fromCsv = readFromCsv("resources/metadata.csv");
					
					for(String [] col : fromCsv) {
						if(col[0].equalsIgnoreCase(strTableName)) {
							//throw new DBAppException("This table already exists");
							return;
						}
					}
					
					List<String[]> dataList = new ArrayList<>();
					// insert here in the data list
					for (String colName : htblColNameType.keySet()) {
				        String colType = htblColNameType.get(colName);
				        String isClusteringKey = colName.equals(strClusteringKeyColumn) ? "True" : "False";
				        String colMin = htblColNameMin.get(colName);
				        String colMax = htblColNameMax.get(colName);

				        String[] colData = {strTableName, colName, colType, isClusteringKey,"null", "null", colMin, colMax};
				        dataList.add(colData);
				    }
					Collections.reverse(dataList);
					
					writeToCsv("resources/metadata.csv", dataList);
					
	}
	
	public static List<String[]> readFromCsv(String filePath) {
	    List<String[]> dataList = new ArrayList<>();

	    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
	        String line;
	        while ((line = br.readLine()) != null) {
	            String[] data = line.split(",");
	            dataList.add(data);
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    
	    return dataList;
	}
	
	
	public static void writeToCsv(String filePath, List<String[]> dataList) {
	    try {
	        FileWriter writer = new FileWriter(filePath,true);
	        for (String[] data : dataList) {
	            for (int i = 0; i < data.length; i++) {
	                writer.append(data[i]);
	                if (i != data.length - 1) {
	                    writer.append(",");
	                }
	            }
	            writer.append("\n");
	        }
	        writer.flush();
	        writer.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public void addPage() {
		this.pageID++;
		Page p = new Page(this.pageID, this);
		String pagePath = STATIC_DIR + this.getStrTableName() + "_" + "Page" + this.pageID + ".ser";
		this.pagesPath.put(this.pageID, pagePath); 
		writePage(p ,pagePath ); //Serializing 
		//p = null;
		 
	}

	public void deletePage(String pagePath) {
		
		 this.pageID--;
		 File pageFile = new File(pagePath);
		 
		 if (pageFile.delete()) {
			 System.out.println("delete successfully");
		 }
		 else {
			 
			 System.out.println("faileddd");
		 }
		
		 
	}


	public void writePage(Page p , String address) {
		
		try {
			FileOutputStream fileOut = new FileOutputStream(address);
	        ObjectOutputStream out = new ObjectOutputStream(fileOut);
	        out.writeObject(p);
	        out.close();
	        fileOut.close();
	       //System.out.println("Serialized data is saved in " + address);
	     } catch (IOException i) {
	        i.printStackTrace();
	     }
		 System.gc();

	}

	
	public String getStrTableName() {
		return strTableName;
	}
	
	public int getPageID() {
		return this.pageID;
	}
	
	public void setPageID(int pageID) {
		this.pageID = pageID;
	}
	
	public Hashtable<Integer, String> getPagesPath() {
		return pagesPath;
	}

	public void setPagesPath(Hashtable<Integer, String> pagesPath) {
		this.pagesPath = pagesPath;
	}
}
