import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public class Page implements Serializable {
	
	private int pageNo ; //Page number
	private  Vector<Hashtable <String,Object>> rows ;
	private Table parentTable ;
	private int maxRows;
	private Object minPK;
	private Object maxPK;
	
	public Page(int pageNo,Table parentTable) {
		this.pageNo= pageNo;
		this.parentTable = parentTable;
		this.minPK=null;
		this.maxPK=null;
		this.maxRows= readFromConfig();
		this.rows = new Vector<Hashtable <String,Object>>();		
	}

	
	public boolean isFull () {
		return rows.size()==maxRows;
	}

	
	public int getPageNo() {
		return pageNo;
	}


	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}


	public Vector<Hashtable<String, Object>> getRows() {
		return rows;
	}

	
	public void setRows(Vector<Hashtable<String, Object>> rows) {
		this.rows = rows;
	}


	public Table getParentTable() {
		return parentTable;
	}


	public Object getMinPK() {
		return minPK;
	}


	public void setMinPK(Object minPK) {
		this.minPK = minPK;
	}



	public Object getMaxPK() {
		return maxPK;
	}



	public void setMaxPK(Object maxPK) {
		this.maxPK = maxPK;
	}
	
	
	public static int readFromConfig() {
		Properties prop = new Properties();
		try (FileInputStream fis = new FileInputStream("resources/DBApp.config")) { //what file name to write here
		    prop.load(fis);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		int N= Integer.parseInt(prop.getProperty("MaximumRowsCountinTablePage"));
		return N;
	}
	
	
}
